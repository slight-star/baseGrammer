package cn.bistu.service;

import cn.bistu.domain.User;

/**
 * @author dfx
 */
public interface UserService {
    User login();
}
