package cn.bistu.service;

import cn.bistu.domain.User;

/**
 * @author dfx
 */
public class UserServiceImpl implements UserService {
    @Override
    public User login() {
        return null;
    }
}
