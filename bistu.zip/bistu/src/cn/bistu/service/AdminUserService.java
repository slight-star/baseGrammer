package cn.bistu.service;

import cn.bistu.domain.AdminUser;

/**
 * @author dfx
 */
public interface AdminUserService {
    AdminUser login(AdminUser adminUser);
}
